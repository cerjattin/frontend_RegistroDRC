// src/styles/theme.ts
export const colors = {
  primary: "#23C062",
  primaryDark: "#1BA152",
  accent: "#7A00D2",
  border: "#D2E5D9",
};
