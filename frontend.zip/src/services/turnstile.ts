export type TurnstileToken = string;
